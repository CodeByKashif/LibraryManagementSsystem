﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Library_management_system.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult BookList()
        {
            return View("BookList");
        }
        public ActionResult StudentList()
        {
            return View("StudentList");
        }
        public ActionResult Issue_Return()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Index()
        {
            
            return View();
        }
        [HttpPost]
        public ActionResult Index(string User,string Password)
        { 
            
            return RedirectToAction("BookList", "Home");
        }



    }
}