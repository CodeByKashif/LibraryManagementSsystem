﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Library_management_system.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult AdminTask()
        {
            return View();
        }
        public ActionResult AddBook()
        {
            return View();
        }
        public ActionResult RemoveBook()
        {
            return View();
        }
        public ActionResult AddStudent()
        {
            return View();
        }
        public ActionResult RemoveStudent()
        {
            return View();
        }
        public ActionResult updateBookRec()
        {
            return View();
        }

    }
}